# Arduino project for SquareLine Studio with Arduino_GFX

## Get started

1. Open the `.ino` file in Arduino
2. Go to File/Preferences and set Sketchbook location to the path of your UI project (where this README is located)
3. Go to `libraries/ui/ui.ino` and open with a text editor to configure bus for your display maybe check rotation settings
4. Select your board (install if needed)
5. Build the project


