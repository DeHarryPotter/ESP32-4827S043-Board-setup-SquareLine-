/*******************************************************************************
 * Touch libraries:
 * FT6X36: https://github.com/strange-v/FT6X36.git
 * GT911: https://github.com/TAMCTec/gt911-arduino.git
 * XPT2046: https://github.com/PaulStoffregen/XPT2046_Touchscreen.git
 
 Manualy ported by Nicolini Texel Holland
 ******************************************************************************/


/* uncomment for XPT2046 */
 #define TOUCH_XPT2046
 #define TOUCH_XPT2046_SCK 12
 #define TOUCH_XPT2046_MISO 13
 #define TOUCH_XPT2046_MOSI 11
 #define TOUCH_XPT2046_CS 38
 #define TOUCH_XPT2046_INT 18
 #define TOUCH_XPT2046_ROTATION 0
 // to tune next values run touch calliebration sketch to get values for your screen
 #define TOUCH_MAP_X1 3883
 #define TOUCH_MAP_X2 198
 #define TOUCH_MAP_Y1 318
 #define TOUCH_MAP_Y2 3851
 #define TOUCH_XPT2046_SAMPLES 50

int touch_last_x = 0, touch_last_y = 0;

bool touch_touched_flag = true, touch_released_flag = true;
 uint16_t touch_max_x = 0;
 uint16_t touch_max_y = 0;

#include "XPT2046_Touchscreen.h"
#include <SPI.h>
XPT2046_Touchscreen ts(TOUCH_XPT2046_CS, TOUCH_XPT2046_INT);



void touch_init(int max_x, int max_y)
{
  touch_max_x = max_x;
  touch_max_y = max_y;

  SPI.begin(TOUCH_XPT2046_SCK, TOUCH_XPT2046_MISO, TOUCH_XPT2046_MOSI, TOUCH_XPT2046_CS);
  ts.begin();
  ts.setRotation(TOUCH_XPT2046_ROTATION);
}

bool touch_has_signal()
{

  return ts.tirqTouched();


}

bool touch_touched()
{

  if (ts.touched())
  {
    TS_Point p = ts.getPoint();
#if defined(TOUCH_SWAP_XY)
    touch_last_x = map(p.y, TOUCH_MAP_X1, TOUCH_MAP_X2, 0, touch_max_x - 1);
    touch_last_y = map(p.x, TOUCH_MAP_Y1, TOUCH_MAP_Y2, 0, touch_max_y - 1);
#else
    touch_last_x = map(p.x, TOUCH_MAP_X1, TOUCH_MAP_X2, 0, touch_max_x - 1);
    touch_last_y = map(p.y, TOUCH_MAP_Y1, TOUCH_MAP_Y2, 0, touch_max_y - 1);
#endif
    return true;
  }
  else
  {
    return false;
  }

}

bool touch_released()
{

  return true;

}
